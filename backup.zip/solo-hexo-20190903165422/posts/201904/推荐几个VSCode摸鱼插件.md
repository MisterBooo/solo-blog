title: 推荐几个 VSCode 摸鱼插件
date: '2019-04-04 10:46:57'
updated: '2019-04-25 09:35:22'
tags: [分享]
permalink: /articles/2019/04/04/1554346017185.html
---

周三是一周中最难以度过的一天，离上个周末过去了两天，离下个周末也还有两天。为了让各位更好地搬(mo)砖(yu)，今天给大家推荐三款效(mo)率(yu)工(shen)具(qi)！

### 一、听歌插件

![1](https://user-gold-cdn.xitu.io/2019/3/6/1695071313885d06?w=1200&h=800&f=gif&s=549214)

#### 功能

- 发现音乐 (歌单 / 新歌 / 排行榜)
- 搜索 (单曲 / 歌手 / 专辑 / 歌单)
- 用户登录 (手机号 / 邮箱)
- 用户收藏 (歌单 / 歌手 / 专辑)
- 每日歌曲推荐
- 喜欢音乐
- 逐行歌词
- 热门评论

下载地址：[https://github.com/nondanee/vsc-netease-music](https://github.com/nondanee/vsc-netease-music)

来源：https://www.v2ex.com/t/540219

### 二、看小说插件

![](https://user-gold-cdn.xitu.io/2019/3/6/16950713163c6eaa?w=1533&h=1080&f=jpeg&s=229827)



#### 功能

- 支持字体大小，字体颜色#6a9955 自定义
- 阅读进度显示以及自动记录
- 支持目录跳转
- 书架编辑

下载地址：https://github.com/my-soul/read-vscode-e

来源：https://www.v2ex.com/t/538745

### 三、看番插件

![1](https://user-gold-cdn.xitu.io/2019/3/6/16950714806b36bf?w=1032&h=808&f=jpeg&s=333884)



#### 功能

- 每日番剧: 从[bangumi](https://bgm.tv/)上获取番剧
- 一言: 随机从网络获取一条 acgn 句子



下载地址：https://github.com/deepred5/daily-anime

来源：https://www.v2ex.com/t/536904
